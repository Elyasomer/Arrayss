const div2 = document.querySelector('#div2')
const btn = document.querySelector('#btn')
btn.addEventListener('click', () => {

const fname = document.querySelector('#fname').value
const lname = document.querySelector('#lname').value
let arr = [{firstname: fname, lastname: lname,}]

arr.forEach((b, i) => {
div2.appendChild(document.createElement("P")).innerText= `${b.firstname} ${b.lastname}` 
})
})
